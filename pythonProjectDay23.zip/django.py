"""
Django is the python webframework

www.djangoproject.com

user -> browser -> urls -> views -> models -> DB -> templates

MTV -> Model Template View

create a project -

django-admin startproject <projectname>

create a folder in the below structure
    projectname is polling_system

    polling_system - root
        polling_system - python package ( polling_system.urls )
            __init__.py
            settings.py - Configuration for the django project
            urls.py -  table of contents
            asgi.py - ASGI Web Server
            wsgi.py - WSGI Web Server
        manage.py - command-line utility that lets you interact with the django project in several ways.

    running the development server
        -python manage.py runserver <port>/<ip:port> in the root path of the project

    Project - Student Management System
        Timetable
        Exam
        Fees
        Performance

    Project - Polling System
        polls

    python manage.py startapp <appname>

    polls/
        __init__.py
        admin.py
        apps.py
        migrations/
            __init__.py
        models.py
        tests.py
        views.py


    create a route named "hello" and it should "Welcome to the polling system"

    path(pattern,view-method,name,kwargs)

    Project Called Maths
        base-route path("calculator/",include("calculator.urls"))

        Applicaiton called Calculator
            views.py
                add
                mul
                sub
                div
            urls.py
            app-route
                path("addition/",views.add)
                path("mul/",views.mul)
                path("sub/",views.sub)
                path("div/",views.div)

            browser - /calculator/addition -
                      /calculator/add - it will not work

Migrations - capture all your schema changes (model changes)

    django has some default tables

    python manage.py migrate

    python manage.py makemigrations

admin:
    python manage.py createsuperuser
"""